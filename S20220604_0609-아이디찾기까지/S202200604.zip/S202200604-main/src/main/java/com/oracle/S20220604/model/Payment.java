package com.oracle.S20220604.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Payment {
	private int pay_tot_num; 	 	private int pay_tot;
	private String user_id;		 	private int pay_state;
	private String pay_name; 		private String pay_address;
	private String pay_tell; 		private int cp_state;
	private int cp_num;				private String pay_req;
	private Date pay_date;
	
	
}


