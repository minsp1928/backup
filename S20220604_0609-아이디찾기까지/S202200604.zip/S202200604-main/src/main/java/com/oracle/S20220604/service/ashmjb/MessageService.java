package com.oracle.S20220604.service.ashmjb;

import com.oracle.S20220604.model.Message;

public interface MessageService {
	int			insert(Message message);
}
