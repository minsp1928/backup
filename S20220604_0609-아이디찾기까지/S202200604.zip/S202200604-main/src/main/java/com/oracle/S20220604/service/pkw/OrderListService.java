package com.oracle.S20220604.service.pkw;

public interface OrderListService {
	int total();
	
}
