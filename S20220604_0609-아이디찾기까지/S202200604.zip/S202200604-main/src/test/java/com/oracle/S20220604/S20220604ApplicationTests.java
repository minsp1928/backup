package com.oracle.S20220604;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S20220604ApplicationTests {

	@Test
	void contextLoads() {
	}

}
