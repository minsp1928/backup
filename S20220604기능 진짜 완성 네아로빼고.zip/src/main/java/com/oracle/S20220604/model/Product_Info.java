package com.oracle.S20220604.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product_Info {

   private int pro_type1;
   private int pro_type2;
   private String pro_content;
}