package com.oracle.S20220604.service.jsh;

import org.springframework.stereotype.Service;

@Service
public class ReviewServiceImpl implements ReviewService {

}
