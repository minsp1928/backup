package com.oracle.S20220604.dao.ashmjb;

import com.oracle.S20220604.domain.Chatting;

public interface ChattingDao {
	Chatting 		save(Chatting chatting);
}
