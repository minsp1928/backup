package com.oracle.S20220604.dao.kge;

public class Sample {

}
