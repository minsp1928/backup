package com.oracle.S20220604.service.pms;


import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.oracle.S20220604.model.Member;

public interface MainLoginService {
	//로그인
	Member login(Member member);
	//아이디 찾기
	Member findIdCheck(Member member);
	//비밀번호 찾기
	Member findPwCheck(Member member);
	//임시비밀번호 메일보내기
	int updateTempPassword(Member member5);
	//아이디중복체크
	void checkId(String user_id, HttpServletResponse response) throws IOException;

}
