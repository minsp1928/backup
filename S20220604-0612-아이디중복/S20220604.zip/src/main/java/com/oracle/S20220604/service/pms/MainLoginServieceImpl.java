package com.oracle.S20220604.service.pms;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.oracle.S20220604.dao.pms.MainLoginDao;
import com.oracle.S20220604.model.Member;

@Service
public class MainLoginServieceImpl implements MainLoginService {
	
	@Autowired MainLoginDao md;
	
	@Override
	public Member login(Member member) {
		System.out.println("MainLoginServieceImpl login Start");
		return md.selectLogin(member);
	}

	@Override
	public Member findIdCheck(Member member) {
		System.out.println("MainLoginServieceImpl findIdCheck Start");
		return md.findId(member);
	}

	@Override
	public Member findPwCheck(Member member) {
		System.out.println("MainLoginServieceImpl findPwCheck Start");
		return md.findPw(member);
	}

	@Override
	public int updateTempPassword(Member member5) {
		System.out.println("MainLoginServieceImpl updateTempPassword Start..");
		return md.updateTempPw(member5);
	}

	@Override
	public void checkId(String user_id, HttpServletResponse response) throws IOException {
		System.out.println("MainLoginServieceImpl checkId Start");
		Member member = new Member();
		member = md.checkId(user_id);
		if(member == null) {//셀렉된 아이디가 없을때 아이디 사용가능
			response.getWriter().print("1");
		}else { //셀렉된 아이디가 있음 = 아이디 중복
			response.getWriter().print("0");
		}
		
	}

}
