package com.oracle.S20220604.service.ashmjb;

import com.oracle.S20220604.domain.Chatting;

public interface ChattingService {
	int 		insert(Chatting chatting);
}
