package com.oracle.S20220604.dao.mja;

import org.springframework.stereotype.Repository;

@Repository
public class PaymentManageDaoImpl implements PaymentManageDao {

}
