package com.oracle.S20220604.dao.pkw;

public class Sample {

}
