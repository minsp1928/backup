package com.oracle.S20220604.model;

import java.util.Date;

public class Shoppingbasket {
	private int basket_num;  
	private int pro_num;
	private int basket_amount;
	private Date basket_date;
	private String user_id;
}
