package com.oracle.S202200604;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S202200604ApplicationTests {

	@Test
	void contextLoads() {
	}

}
