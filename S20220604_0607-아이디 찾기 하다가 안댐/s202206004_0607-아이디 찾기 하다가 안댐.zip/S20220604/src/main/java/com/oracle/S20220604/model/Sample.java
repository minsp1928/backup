package com.oracle.S20220604.model;

public class Sample {

}
