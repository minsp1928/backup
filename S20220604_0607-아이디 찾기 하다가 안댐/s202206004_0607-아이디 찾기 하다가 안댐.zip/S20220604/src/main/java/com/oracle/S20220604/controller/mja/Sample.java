package com.oracle.S20220604.controller.mja;

public class Sample {

}
