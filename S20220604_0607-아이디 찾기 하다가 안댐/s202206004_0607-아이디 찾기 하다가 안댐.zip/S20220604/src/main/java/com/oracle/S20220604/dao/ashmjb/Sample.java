package com.oracle.S20220604.dao.ashmjb;

public class Sample {

}
