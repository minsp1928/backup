package com.oracle.S20220604.service.mja;

public class Sample {

}
