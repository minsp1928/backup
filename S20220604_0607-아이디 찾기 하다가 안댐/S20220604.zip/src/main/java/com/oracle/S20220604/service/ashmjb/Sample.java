package com.oracle.S20220604.service.ashmjb;

public class Sample {

}
