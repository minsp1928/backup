package com.oracle.S20220604.service.jsh;

public interface ShoppingbasketService {

}
