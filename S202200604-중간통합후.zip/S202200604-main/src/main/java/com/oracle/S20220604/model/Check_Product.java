package com.oracle.S20220604.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Check_Product {
	private int pro_num;
	private String user_id;
}
