package com.oracle.S20220604.controller.kge;

public class Sample {

}
