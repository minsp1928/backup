package com.oracle.S20220604.dao.ashmjb;

import com.oracle.S20220604.model.Message;

public interface MessageDao {
	int 		insert(Message message);
}
