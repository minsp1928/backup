package com.oracle.S20220604.service.kge;

public class Sample {

}
