package com.oracle.S20220604.dao.mja;

public interface PaymentManageDao {

}
