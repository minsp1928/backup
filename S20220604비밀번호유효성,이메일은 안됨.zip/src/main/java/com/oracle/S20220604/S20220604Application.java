package com.oracle.S20220604;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S20220604Application {

	public static void main(String[] args) {
		SpringApplication.run(S20220604Application.class, args);
	} 

}
